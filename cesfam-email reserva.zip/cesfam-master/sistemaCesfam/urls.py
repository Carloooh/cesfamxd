from django.urls import path
from . import views
from django.contrib import admin
import django

urlpatterns = [

    path('', views.med),
    path('admin/', admin.site.urls),
    path('medico/', views.medico),
    path('login/', views.med, name='login'),
    path('cerrarSesion/', views.cerrarSesion,name='cerrarSesion'),
    path('medico/', views.medico),
    path('gestionBodega/', views.gestionBodega),
    path('editarMedicamentos/', views.editarMedicamento),
    path('eliminarMedicamento/<codigo>', views.eliminarMedicamento),
    path('gestionBodega/edicionMedicamento/<codigo>', views.edicionMedicamento),
    path('registrarMedicamento/', views.registrarMedicamento),
    path('guardarReceta',views.guardarReceta, name='guardarReceta'),
    path('crearReceta/',views.crearReceta, name='crearReceta'),
    path('reservar/<codigo>',views.reservar),
    path('reservarMed/',views.reservarMed)
]
