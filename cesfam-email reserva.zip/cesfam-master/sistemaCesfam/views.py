
from django.contrib import messages
from wsgiref.util import request_uri
from django.shortcuts import render, redirect
from django.http import HttpResponse, JsonResponse
from django.db.models import Q
from django.core import serializers

from json import dumps

from django.template.loader import render_to_string 
from django.core.mail import EmailMessage 
from django.conf import settings

from urllib.request import urlopen
import json

from .models import Medicamento, Reserva, medicamentos, Usuario, Receta
# Create your views here.

def medico(request):
    medicamentosListado = Medicamento.objects.all()
    # medicamentosQuery = Medicamento.objects.filter(Q(nombre__icontains = "pa") | Q(descripcion__icontains="v"))
    listaMedicamentos = dumps(list(medicamentosListado.values()))
    return render(request,'medico.html', {"listaMedicamentos": listaMedicamentos})

def med(request):
    messages=''
    if request.method == 'POST':
        try:
            detalleUsuario = Usuario.objects.get(nombre=request.POST['usuario'], contra=request.POST['contra'])
            request.session['nombre']=detalleUsuario.nombre
            if detalleUsuario.tipoUsuario == 'med':
                medicamentosListado = Medicamento.objects.all()
                listaMedicamentos = dumps(list(medicamentosListado.values()))
                return render(request,'medico.html', {'listaMedicamentos': listaMedicamentos})
            elif detalleUsuario.tipoUsuario == 'farm': 
                medicamentosListado = Medicamento.objects.all()
                listaMedicamentos = dumps(list(medicamentosListado.values()))
                recetas = Receta.objects.all()
                recetass = dumps(list(recetas.values()))
                return render(request, 'farmaceutico.html',{'recetas':recetas, 'listaMedicamentos': listaMedicamentos, 'recetass':recetass})
            else:
                return render(request, 'adm.html')           
        except:
            messages=(request,'Credenciales Incorrectas')
    return render(request, 'login.html',{'messages':messages})

def cerrarSesion(request):
    try:
        del request.session['nombre']
    except:
        return redirect('/')
    return redirect('/')

def crearReceta(request):
    medicamentosListado = Medicamento.objects.all()
    listaMedicamentos = dumps(list(medicamentosListado.values()))
    return render(request,'crearReceta.html',{'listaMedicamentos':listaMedicamentos})

def guardarReceta(request):
    medicamentosListado = Medicamento.objects.all()
    listaMedicamentos = dumps(list(medicamentosListado.values()))
    if request.method == 'POST':
        codigo = request.POST['idReceta']
        # fecha = request.POST['fechaReceta']
        fecha = 'HOY'
        nombrePaciente = request.POST['nombrePacienteReceta']
        rutPaciente = request.POST['rutPacienteReceta'] 
        descripcion = request.POST['descripcion']
        url = "https://jsoncesfam.herokuapp.com/medicamentos"
        response = urlopen(url)
        data_json = json.loads(response.read())
        # medicamentos = json.dumps(data_json)
        medicamentos = data_json
        receta = Receta.objects.create(codigo=codigo, fecha=fecha, nombrePaciente=nombrePaciente, rutPaciente=rutPaciente, descripcion=descripcion, medicamentos=medicamentos)
        
        print(medicamentos)
        return redirect('crearReceta')
    else:
        return redirect('crearReceta')


    #Matias here
def gestionBodega(request):
    medicamentosListados= medicamentos.objects.all()
    return render(request, "gestionMedicamentos.html", {"medicamentos": medicamentosListados})



def eliminarMedicamento(request,codigo):
    medica = medicamentos.objects.get(codigo=codigo)
    medica.delete()
    return redirect('/gestionBodega')


def registrarMedicamento(request):
    codigo=request.POST['txtCodigo']
    nombre=request.POST['txtNombre']
    stock=request.POST['numStock']
    imagen=request.FILES['txtImagen']
    
    medica= medicamentos.objects.create(
        codigo=codigo, nombre=nombre, stock=stock, imagen=imagen)
    return redirect('/gestionBodega')

def reservar(request,codigo):
    med = Medicamento.objects.get(id=codigo)
    return render(request, "reservar.html",{"med": med})

def reservarMed(request):
    idReserva = request.POST['code']
    idMedicamento = request.POST['IdReserva']
    nombre = request.POST['nombre']
    email = request.POST['email']
    reseva = Reserva.objects.create(idReserva=idReserva, idMedicamento=idMedicamento, nombre=nombre,email=email)
    html_template = 'emailreserva.html' 
    html_message = render_to_string(html_template, context=mydict) 
    subject = 'Reserva medicamento' 
    email_from = settings.EMAIL_HOST_USER 
    recipient_list = [email] 
    message = EmailMessage(subject, html_message, email_from, recipient_list)           
    message.content_subtype = 'html' 
    message.send() 
    return redirect('/')

def edicionMedicamento(request,codigo):
    medica = medicamentos.objects.get(codigo=codigo)
    return render(request, "edicionMedicamentos.html",{"medicamentos": medica})


def editarMedicamento(request):
    codigo=request.POST['txtCodigo']
    nombre=request.POST['txtNombre']
    stock=request.POST['numStock']
    imagen=request.FILES['txtImagen']
    medica = medicamentos.objects.get(codigo=codigo)
    medica.nombre = nombre
    medica.stock = stock
    medica.imagen= imagen
    medica.save()
    
    return redirect('/gestionBodega')