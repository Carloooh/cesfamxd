from atexit import register
from django.contrib import admin
from .models import Receta,Paciente, Meds_Entregados, Medicamento, Usuario, medicamentos, Reserva

# Register your models here.

admin.site.register(Medicamento)
admin.site.register(Usuario)
admin.site.register(Paciente)
admin.site.register(Receta)
admin.site.register(Meds_Entregados)
admin.site.register(medicamentos)
admin.site.register(Reserva)