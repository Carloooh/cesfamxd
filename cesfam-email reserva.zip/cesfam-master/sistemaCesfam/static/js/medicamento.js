// Limpiar formulario al cerrar modal
function limpiarFormulario(){
    document.getElementById("datosPaciente").reset();
    document.getElementById("agregarMedicamento").reset();
}



