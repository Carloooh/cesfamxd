from django.shortcuts import render,redirect
from django.http import HttpResponse, JsonResponse
from django.db.models import Q
from django.core import serializers

from json import dumps



from .models import Medicamento,medicamentos
# Create your views here.

def index(request):
    return render(request,'login.html')

def medico(request):
    medicamentosListado = Medicamento.objects.all()
    medicamentosQuery = Medicamento.objects.filter(Q(nombre__icontains = "pa") | Q(descripcion__icontains="v"))
    # listaMedicamentos = serializers.serialize("json", medicamentosListado)
    listaMedicamentos = dumps(list(medicamentosListado.values()))

    return render(request,'medico.html', {"medicamentos":medicamentosListado, "medicamentosQ":medicamentosQuery, "listaMedicamentos": listaMedicamentos})



    #Matias here
def gestionBodega(request):
    medicamentosListados= medicamentos.objects.all()
    return render(request, "gestionMedicamentos.html", {"medicamentos": medicamentosListados})



def eliminarMedicamento(request,codigo):
    medica = medicamentos.objects.get(codigo=codigo)
    medica.delete()
    return redirect('/gestionBodega')


def registrarMedicamento(request):
    codigo=request.POST['txtCodigo']
    nombre=request.POST['txtNombre']
    stock=request.POST['numStock']
    imagen=request.FILES['txtImagen']
    
    medica= medicamentos.objects.create(
        codigo=codigo, nombre=nombre, stock=stock, imagen=imagen)
    return redirect('/gestionBodega')


def edicionMedicamento(request,codigo):
    medica = medicamentos.objects.get(codigo=codigo)
    return render(request, "edicionMedicamentos.html",{"medicamentos": medica})


def editarMedicamento(request):
    codigo=request.POST['txtCodigo']
    nombre=request.POST['txtNombre']
    stock=request.POST['numStock']
    imagen=request.FILES['txtImagen']
    medica = medicamentos.objects.get(codigo=codigo)
    medica.nombre = nombre
    medica.stock = stock
    medica.imagen= imagen
    medica.save()
    
    return redirect('/gestionBodega')