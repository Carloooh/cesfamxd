from django.urls import path
from . import views
from django.contrib import admin
import django

urlpatterns = [
    path('', views.index),
    path('admin/', admin.site.urls),
    path('medico/', views.medico),
    path('gestionBodega/', views.gestionBodega),
    path('editarMedicamentos/', views.editarMedicamento),
    path('eliminarMedicamento/<codigo>', views.eliminarMedicamento),
    path('edicionMedicamento/<codigo>', views.edicionMedicamento),
    path('registrarMedicamento/', views.registrarMedicamento),
]
